from tkinter import *
from tkinter import messagebox
import random 

next_move1 = NONE

def clicked():
    window.after_cancel(next_move1)
    messagebox.showinfo("미션 성공!!", "클릭성공 축하합니다!!")
    window.quit()

def btn_move1():
    global next_move1
    new_x = random.randint(50, 450)
    new_y = random.randint(50, 450)
    button.place(x=new_x, y=new_y)
    next_move1 = window.after(350, btn_move1)

window = Tk()
window.title("파리 잡기 게임")
window.geometry("500x500")
window.resizable(False, False)

img = PhotoImage(file="img2.png")
button = Button(window, image=img, command=clicked)
button.place(x=250, y=250)

btn_move1()


window.mainloop()

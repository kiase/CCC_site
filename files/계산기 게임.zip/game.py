from tkinter import *
import random

IVORY = "#FFE4C0"
PINK = "#FFBBBB"
BLUE = "#BFFFF0"
GREEN = "#BFFFF0"

answer = "100"  #답  

start_number = "1000" #시작 숫자

try_ = 0  #시도횟수(터치 X)

limite = 1000 #횟수제한

digits = [
    ["", "", "", ""],  #배열
    ["", "", "", ""],
    ["", "", "", ""],
    ["", "", "", ""]
]

def clicked(digit):
    result = eval(input_entry.get())
    result = str(int(float(result)))

    global answer 
    global try_
    global limite

    if str(digit) != "":
        if try_ >= limite:
            answer_label.config(text="기회소진")

        elif str(result) == str(answer):
            answer_label.config(text="정답")

        else :
            input_entry.insert(END, digit)
            calculate()



def del_digit():
  input_entry.delete(0, END)

def calculate():

    result = eval(input_entry.get())
    result = str(int(float(result)))

    global answer 
    global try_
    global limite

    try_ += 1
    window.title(str(try_) +","+ str(limite))
    input_entry.delete(0, END)
    input_entry.insert(END, result)

    if str(result) == str(answer):
      answer_label.config(text="정답")

def arrangement():
    global try_
    global limite
    global answer
    global IVORY
    global start_number
    global digits
    global input_entry
    global answer_label


    window.title(""+ title_ +", try : " + str(try_) +", limite : "+ str(limite))
    window.resizable(False, False)
    window.config(padx=10, pady=10, bg=IVORY)

    input_entry = Entry(window , width=30, font=("Showcard Gothic", 20),                     
                        bg=IVORY, justify=RIGHT)
    input_entry.grid(column=0, row=0, columnspan=4)
    input_entry.focus()

    answer_label = Label(window, text=answer, width=10, font=("Showcard Gothic", 30), bg=IVORY)  
    answer_label.grid(column=0, row=1, columnspan = 4, pady=15)
    answer_label.focus()

    input_entry.insert(END, start_number)


    for r in range(4):
        for c in range(4):
            digit = digits[r][c]
            button = Button(window, text=digit, width=8, font=("Showcard Gothic", 15),
                            bg=PINK, command=lambda x=digit: clicked(x))
            button.grid(row=r+2, column=c, pady=2)


def problem1():

    global answer, start_number, try_, limite, digits, title_

    answer = "10"

    start_number = "60" 

    try_ = 0 

    limite = 6

    title_ = "문제 1"

    digits = [
        ["", "", "", ''],  
        ["", "-5", "+6", ''],
        ["", "", "/8", ''],
        ["+4", '', '', '']
    ]
		
    arrangement()
    
def problem2():

    global answer, start_number, try_, limite, digits, title_

    answer = "126"

    start_number = "0" 

    try_ = 0 

    limite = 6

    title_ = "문제 2"

    digits = [
        ["", "*2", "", '+10'],  
        ["", "", "", ''],
        ["+4", "*10", "", ''],
        ["", '', '-44', '']
    ]

    arrangement()

def problem3():

    global answer, start_number, try_, limite, digits, title_

    answer = "13"

    start_number = "56" 

    try_ = 0 

    limite = 6

    title_ = "문제 3"

    digits = [
        ["/9", "", "", '+5'],  
        ["", "", "", ''],
        ["-14", "+10", "", ''],
        ["", '', '-2', '']
    ]

    arrangement()
    
def problem4():

    global answer, start_number, try_, limite, digits, title_

    answer = "73"

    start_number = "7" 

    try_ = 0 

    limite = 5

    title_ = "문제 4"

    digits = [
        ["-30", "", "-2", ''],  
        ["", "", "", ''],
        ["", "+4", "", '*5'],
        ["*3", '', '', '']
    ]

    arrangement()

def problem5():

    global answer, start_number, try_, limite, digits, title_

    answer = "23"

    start_number = "14" 

    try_ = 0 

    limite = 6

    title_ = "문제 5"

    digits = [
        ["+2", "", "", '+1'],  
        ["", "", "/5", ''],
        ["*3", "", "", ''],
        ["", '', '*2', '']
    ]

    arrangement()

def problem6():

    global answer, start_number, try_, limite, digits, title_

    answer = "57"

    start_number = "81" 

    try_ = 0 

    limite = 4

    title_ = "문제 6"
    
    digits = [
        ["", "", "*3", ''],  
        ["", "", "", ''],
        ["*2", "", "", '/18'],
        ["", '+10', '', '']
    ]

    arrangement()
    
def problem7():

    global answer, start_number, try_, limite, digits, title_

    answer = "66"

    start_number = "300" 

    try_ = 0 

    limite = 5

    title_ = "문제 7"

    digits = [
        ["+1", "", "/2", ''],  
        ["", "", "", ''],
        ["/10", "", "", '+5'],
        ["", '', '*4', '']
    ]

    arrangement()

def problem8():

    global answer, start_number, try_, limite, digits, title_

    answer = "147"

    start_number = "23" 

    try_ = 0 

    limite = 5

    title_ = "문제 8"

    digits = [
        ["", "+6", "", ''],  
        ["", "", "-3", '-1'],
        ["+2", "", "", ''],
        ["", '', '*5', '']
    ]

    arrangement()

def problem9():

    global answer, start_number, try_, limite, digits, title_

    answer = "294"

    start_number = "999" 

    try_ = 0 

    limite = 5

    title_ = "문제 9"

    digits = [
        ["", "", "/9", ''],  
        ["/3", "", "", ''],
        ["", "*6", "", '+9'],
        ["", '', '+3', '']
    ]

    arrangement()

def problem10():

    global answer, start_number, try_, limite, digits, title_

    answer = "588"

    start_number = "11" 

    try_ = 0 

    limite = 11

    title_ = "문제 10"

    digits = [
        ["-2", "/2", "", '*2'],  
        ["/4", "", "-5", '/3'],
        ["*4", "/5", "", '+10'],
        ["", '*5', '*6', '+1']
    ]

    arrangement()

def problem11():

    global answer, start_number, try_, limite, digits, title_

    answer = "99"

    start_number = "0" 

    try_ = 0 

    limite = 6

    title_ = "문제 11"

    digits = [
        ["+1", "", "/8", ''],  
        ["", "+2", "", ''],
        ["*4", "", "", '+10'],
        ["", '', '', '*14']
    ]

    arrangement()

def problem12():

    global answer, start_number, try_, limite, digits, title_

    answer = "20"

    start_number = "84" 

    try_ = 0 

    limite = 4

    title_ = "문제 12"

    digits = [
        ["", "", "/7", ''],  
        ["", "", "", '*3'],
        ["", "", "", ''],
        ["/2", '', '+2', '']
    ]

    arrangement()

def problem13():

    global answer, start_number, try_, limite, digits, title_

    answer = "55"

    start_number = "65" 

    try_ = 0 

    limite = 5

    title_ = "문제 13"

    digits = [
        ["", "", "", '+4'],  
        ["*6", "", "", '+8'],
        ["", "/5", "", ''],
        ["", '/2', '', '']
    ]

    arrangement()

def problem14():

    global answer, start_number, try_, limite, digits, title_

    answer = "616"

    start_number = "1" 

    try_ = 0 

    limite = 5

    title_ = "문제 14"

    digits = [
        ["", "*11", "", ""],  
        ["", "", "*2", ""],
        ["", "", "*7", ""],
        ["", "", "", ""]
    ]

    arrangement()

def problem15():

    global answer, start_number, try_, limite, digits, title_

    answer = "1030"

    start_number = "9" 

    try_ = 0 

    limite =4

    title_ = "문제 15"

    digits = [
        ["", "", "", "+3"],  
        ["/3", "", "", ""],
        ["", "", "*10", ""],
        ["", "+10", "", ""]
    ]

    arrangement()
    
def problem16():

    global answer, start_number, try_, limite, digits, title_

    answer = "50"

    start_number = "100" 

    try_ = 0 

    limite = 5

    title_ = "문제 16"

    digits = [
        ["", "", "", '-1'],  
        ["", "", "*2", ''],
        ["/9", "", "", ''],
        ["", '+3', '', '']
    ]

    arrangement()

def problem17():

    global answer, start_number, try_, limite, digits, title_

    answer = "63"

    start_number = "87" 

    try_ = 0 

    limite = 4

    title_ = "문제 17"

    digits = [
        ["", "", "", ''],  
        ["", "", "", '/3'],
        ["-2", "", "", ''],
        ["", '', '*7', '']
    ]

    arrangement()

def problem18():

    global answer, start_number, try_, limite, digits, title_

    answer = "35"

    start_number = "36" 

    try_ = 0 

    limite = 4

    title_ = "문제 18"

    digits = [
        ["", "", "/2", ''],  
        ["", "*5", "", ''],
        ["/3", "", "", ''],
        ["", '', '', '+1']
    ]

    arrangement()

def problem19():

    global answer, start_number, try_, limite, digits, title_

    answer = "13"

    start_number = "7" 

    try_ = 0 

    limite = 4

    title_ = "문제 19"

    digits = [
        ["", "", "+3", ''],  
        ["", "", "", '*3'],
        ["/2", "", "", ''],
        ["", '+1', '', '']
    ]

    arrangement()

def problem20():

    global answer, start_number, try_, limite, digits, title_

    answer = "20"

    start_number = "100" 

    try_ = 0 

    limite = 5

    title_ = "문제 20"

    digits = [
        ["", "", "/2", ""],  
        ["/11", "", "", ""],
        ["", "+10", "", ""],
        ["", "", "", "+5"]
    ]

    arrangement()

    
window = Tk()
menubar = Menu(window)
filemenu = Menu(menubar)
filemenu.add_command(label="문제1", command=problem1)
filemenu.add_command(label="문제2", command=problem2)
filemenu.add_command(label="문제3", command=problem3)
filemenu.add_command(label="문제4", command=problem4)
filemenu.add_command(label="문제5", command=problem5)
filemenu.add_command(label="문제6", command=problem6)
filemenu.add_command(label="문제7", command=problem7)
filemenu.add_command(label="문제8", command=problem8)
filemenu.add_command(label="문제9", command=problem9)
filemenu.add_command(label="문제10", command=problem10)
filemenu.add_command(label="문제11", command=problem11)
filemenu.add_command(label="문제12", command=problem12)
filemenu.add_command(label="문제13", command=problem13)
filemenu.add_command(label="문제14", command=problem14)
filemenu.add_command(label="문제15", command=problem15)
filemenu.add_command(label="문제16", command=problem16)
filemenu.add_command(label="문제17", command=problem17)
filemenu.add_command(label="문제18", command=problem18)
filemenu.add_command(label="문제19", command=problem19)
filemenu.add_command(label="문제20", command=problem20)

menubar.add_cascade(label="문제", menu=filemenu)
window.config(menu=menubar)

window.mainloop()
